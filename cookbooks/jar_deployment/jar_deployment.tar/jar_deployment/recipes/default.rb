#
# Cookbook Name:: jar_deployment
# Recipe:: default
#
# Copyright 2015, Robert Northard
#
# All rights reserved - Do Not Redistribute
#

# Install java
include_recipe 'java::default'
